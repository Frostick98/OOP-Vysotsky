# lab10v2 — Лабораторна робота №6 (варіант 2)

Абстрактні класи та інтерфейси. Висоцький Олександр, ІПЗ-3/1.

- `ISortable` — контракт `void Sort(int[] array)`; реалізації: `BubbleSort`, `QuickSort`.
- `LoggerBase` — абстрактний клас (`abstract WriteLog`, конкретний `LogTimestamp`); похідні: `ConsoleLogger`, `DebugLogger`.
- `Program.cs` — демонстрація поліморфних викликів через `List<ISortable>` і `List<LoggerBase>`.

Запуск: `dotnet run --project OOP-Vysotsky/lab10v2`
